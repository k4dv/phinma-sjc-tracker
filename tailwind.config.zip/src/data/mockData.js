export const DEMO_STAFF = [
  { id: '001', name: 'Kuya Bert', role: 'staff' },
  { id: '002', name: 'Ate Linda', role: 'staff' },
  { id: '003', name: 'Kuya Jun', role: 'staff' },
  { id: '004', name: 'Ate Marites', role: 'staff' },
  { id: '005', name: 'Kuya Jomar', role: 'staff' }
];

export const INITIAL_ASSIGNMENTS = {
  1: '002', // Ate Linda
  2: '002', // Ate Linda
  3: '003', // Kuya Jun
  4: '001', // Kuya Bert
  5: '001', // Kuya Bert
  6: '004', // Ate Marites
  7: '004'  // Ate Marites
};

export const INITIAL_BROADCAST = {
  active: true,
  message: 'VP Operations visiting 5th floor at 2:00 PM. Verify all AC units and doors are secured.',
  postedBy: 'Facilities Supervisor',
  updatedAt: '08:00 AM'
};

const generateRooms = () => {
  const rooms = [];
  for (let floor = 1; floor <= 7; floor++) {
    for (let roomNum = 1; roomNum <= 5; roomNum++) {
      const id = `${floor}0${roomNum}`;
      // Initial mock states across the 3 stages: pending, cleaned, or verified
      let status = 'pending';
      let staff = 'Unassigned';
      let acChecked = false;
      let lightsChecked = false;
      let doorChecked = false;

      if (floor <= 2) {
        status = 'verified';
        staff = 'Ate Linda';
        acChecked = true;
        lightsChecked = true;
        doorChecked = true;
      } else if (floor === 5 && roomNum <= 3) {
        status = 'cleaned'; // Cleaned by staff, waiting for admin sign-off
        staff = 'Kuya Bert';
        acChecked = true;
        lightsChecked = true;
        doorChecked = true;
      }

      rooms.push({
        id,
        floor,
        status, // 'pending' | 'cleaned' | 'verified'
        lastCleaned: status !== 'pending' ? '08:45 AM' : 'Pending inspection',
        staff,
        recleanReason: '',
        acChecked,
        lightsChecked,
        doorChecked
      });
    }
  }
  return rooms;
};

export const INITIAL_ROOMS = generateRooms();

export const INITIAL_SUPPLIES = [
  { id: 'sup-1', name: 'Floor Bleach & Disinfectant', category: 'Chemicals', quantity: 6, unit: 'gals', threshold: 3 },
  { id: 'sup-2', name: 'Commercial Mop Heads', category: 'Equipment', quantity: 2, unit: 'pcs', threshold: 4 },
  { id: 'sup-3', name: 'Heavy-Duty Trash Bags (XL)', category: 'Disposables', quantity: 35, unit: 'rolls', threshold: 10 },
  { id: 'sup-4', name: 'Antibacterial Hand Soap Refill', category: 'Hygiene', quantity: 4, unit: 'liters', threshold: 6 },
  { id: 'sup-5', name: 'Microfiber Cleaning Cloths', category: 'Equipment', quantity: 24, unit: 'pcs', threshold: 10 },
  { id: 'sup-6', name: 'Heavy-Duty Latex Gloves', category: 'PPE', quantity: 3, unit: 'pairs', threshold: 5 },
  { id: 'sup-7', name: 'Toilet Acid Cleaner', category: 'Chemicals', quantity: 8, unit: 'bottles', threshold: 4 },
  { id: 'sup-8', name: 'Paper Towel Rolls', category: 'Disposables', quantity: 12, unit: 'rolls', threshold: 8 }
];

export const INITIAL_LOGS = [
  { id: 'log-1', time: '09:20 AM', author: 'Supervisor', text: 'Floor 1 and 2 rooms verified and approved.' },
  { id: 'log-2', time: '08:50 AM', author: 'Kuya Bert', text: 'Floor 5 rooms 501-503 cleaned, awaiting supervisor sign-off.' },
  { id: 'log-3', time: '08:15 AM', author: 'Ate Linda', text: 'Completed morning sanitation on Floor 1 restrooms & hallway.' }
];