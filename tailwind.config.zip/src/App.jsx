import React, { useState, useEffect } from 'react';
import { Routes, Route, Navigate, useLocation } from 'react-router-dom';
import Header from './components/Header';
import Navbar from './components/Navbar';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Rooms from './pages/Rooms';
import Supplies from './pages/Supplies';
import Admin from './pages/Admin';
import { supabase } from './data/supabaseClient';
import { Megaphone } from 'lucide-react';
import { 
  INITIAL_ROOMS, 
  INITIAL_SUPPLIES, 
  INITIAL_LOGS, 
  INITIAL_ASSIGNMENTS, 
  INITIAL_BROADCAST 
} from './data/mockData';

export default function App() {
  const location = useLocation();

  const [user, setUser] = useState(() => {
    const saved = localStorage.getItem('sjc_active_user') || sessionStorage.getItem('sjc_active_user');
    return saved ? JSON.parse(saved) : null;
  });

  const [rooms, setRooms] = useState(INITIAL_ROOMS);
  const [supplies, setSupplies] = useState(INITIAL_SUPPLIES);
  const [logs, setLogs] = useState(INITIAL_LOGS);
  const [assignments, setAssignments] = useState(INITIAL_ASSIGNMENTS);
  const [broadcast, setBroadcast] = useState(INITIAL_BROADCAST);
  const [onlineUsers, setOnlineUsers] = useState([]);

  // 1. Initial Data Fetch
  useEffect(() => {
    const fetchInitialData = async () => {
      try {
        const [roomsRes, suppliesRes, assignRes, broadRes, logsRes] = await Promise.all([
          supabase.from('rooms').select('*').order('id', { ascending: true }),
          supabase.from('supplies').select('*').order('id', { ascending: true }),
          supabase.from('assignments').select('*'),
          supabase.from('broadcast').select('*').limit(1),
          supabase.from('logs').select('*').order('created_at', { ascending: false }).limit(20)
        ]);

        if (roomsRes.data?.length) {
          const formattedRooms = roomsRes.data.map((r) => ({
            id: r.id,
            floor: r.floor,
            status: r.status,
            staff: r.staff,
            lastCleaned: r.last_cleaned,
            recleanReason: r.reclean_reason,
            acChecked: r.ac_checked,
            lightsChecked: r.lights_checked,
            doorChecked: r.door_checked
          }));
          setRooms(formattedRooms);
        }

        if (suppliesRes.data?.length) setSupplies(suppliesRes.data);

        if (assignRes.data?.length) {
          const assignMap = {};
          assignRes.data.forEach((a) => { assignMap[a.floor] = a.staff_id; });
          setAssignments(assignMap);
        }

        if (broadRes.data && broadRes.data.length > 0) {
          const b = broadRes.data[0];
          setBroadcast({
            active: b.active,
            message: b.message,
            postedBy: b.posted_by,
            updatedAt: b.updated_at
          });
        }

        if (logsRes.data?.length) setLogs(logsRes.data);
      } catch (err) {
        console.warn('Initial Supabase fetch fallback to mock data:', err);
      }
    };

    fetchInitialData();
  }, []);

  // 2. Real-Time WebSocket Subscriptions
  useEffect(() => {
    const channel = supabase
      .channel('schema-db-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'rooms' }, (payload) => {
        if (payload.eventType === 'UPDATE' && payload.new) {
          const updated = payload.new;
          setRooms((prev) => prev.map((r) => r.id === updated.id ? {
            id: updated.id,
            floor: updated.floor,
            status: updated.status,
            staff: updated.staff,
            lastCleaned: updated.last_cleaned,
            recleanReason: updated.reclean_reason,
            acChecked: updated.ac_checked,
            lightsChecked: updated.lights_checked,
            doorChecked: updated.door_checked
          } : r));
        }
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'supplies' }, (payload) => {
        if (payload.eventType === 'UPDATE' && payload.new) {
          const updated = payload.new;
          setSupplies((prev) => prev.map((s) => s.id === updated.id ? updated : s));
        } else if (payload.eventType === 'INSERT' && payload.new) {
          setSupplies((prev) => {
            // Deduplicate: ignore if ID or item name already exists in state
            if (prev.some((s) => s.id === payload.new.id || s.name === payload.new.name)) return prev;
            return [...prev, payload.new];
          });
        } else if (payload.eventType === 'DELETE' && payload.old) {
          setSupplies((prev) => prev.filter((s) => s.id !== payload.old.id));
        }
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'assignments' }, (payload) => {
        if (payload.new) {
          const updated = payload.new;
          setAssignments((prev) => ({ ...prev, [updated.floor]: updated.staff_id }));
        }
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'broadcast' }, (payload) => {
        if (payload.new) {
          const updated = payload.new;
          setBroadcast({
            active: updated.active,
            message: updated.message,
            postedBy: updated.posted_by,
            updatedAt: updated.updated_at
          });
        }
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'logs' }, (payload) => {
        if (payload.eventType === 'INSERT' && payload.new) {
          setLogs((prev) => {
            const isDuplicate = prev.some(
              (item) => item.id === payload.new.id || (item.text === payload.new.text && item.time === payload.new.time)
            );
            if (isDuplicate) return prev;
            return [payload.new, ...prev];
          });
        } else if (payload.eventType === 'DELETE' && payload.old) {
          setLogs((prev) => prev.filter((l) => l.id !== payload.old.id));
        }
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  // 3. Supabase Real-Time Presence
  useEffect(() => {
    if (!user) return;

    const presenceChannel = supabase.channel('online-staff-tracker', {
      config: { presence: { key: String(user.id) } }
    });

    presenceChannel
      .on('presence', { event: 'sync' }, () => {
        const state = presenceChannel.presenceState();
        const activeStaffList = Object.values(state).flatMap((sessions) => sessions);
        setOnlineUsers(activeStaffList);
      })
      .subscribe(async (status) => {
        if (status === 'SUBSCRIBED') {
          await presenceChannel.track({
            id: user.id,
            name: user.name,
            role: user.role,
            onlineAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
          });
        }
      });

    return () => {
      supabase.removeChannel(presenceChannel);
    };
  }, [user]);

  const handleLoginSuccess = (userData, remember) => {
    setUser(userData);
    if (remember) {
      localStorage.setItem('sjc_active_user', JSON.stringify(userData));
      sessionStorage.removeItem('sjc_active_user');
    } else {
      sessionStorage.setItem('sjc_active_user', JSON.stringify(userData));
      localStorage.removeItem('sjc_active_user');
    }
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('sjc_active_user');
    sessionStorage.removeItem('sjc_active_user');
  };

  return (
    <div className="max-w-md mx-auto min-h-screen bg-[#f8fafc] shadow-xl flex flex-col relative overflow-hidden font-sans">
      {user && (
        <Header 
          title={`Hi, ${user.name}`} 
          user={user} 
          onLogout={handleLogout} 
        />
      )}

      {user && broadcast?.active && broadcast?.message && (
        <div className="px-4 pt-3 animate-toast">
          <div className="p-3 bg-amber-50 border border-amber-300 rounded-2xl shadow-xs flex items-start gap-2.5">
            <div className="p-1.5 bg-amber-200/80 text-amber-800 rounded-xl flex-shrink-0">
              <Megaphone className="w-4 h-4" />
            </div>
            <div className="flex-1 text-xs">
              <div className="flex items-center justify-between">
                <span className="font-bold text-amber-950 uppercase tracking-wider text-[10px]">
                  Supervisor Notice
                </span>
                <span className="text-[10px] text-amber-800 font-mono">
                  {broadcast.updatedAt || 'Live'}
                </span>
              </div>
              <p className="text-amber-900 leading-snug font-medium mt-0.5">
                {broadcast.message}
              </p>
            </div>
          </div>
        </div>
      )}

      <main key={location.pathname} className="flex-1 page-transition">
        <Routes location={location}>
          <Route
            path="/login"
            element={user ? <Navigate to="/dashboard" replace /> : <Login onLoginSuccess={handleLoginSuccess} />}
          />

          <Route
            path="/dashboard"
            element={
              user ? (
                <Dashboard
                  rooms={rooms}
                  supplies={supplies}
                  logs={logs}
                  setLogs={setLogs}
                  user={user}
                  assignments={assignments}
                  onlineUsers={onlineUsers}
                />
              ) : (
                <Navigate to="/login" replace />
              )
            }
          />

          <Route
            path="/rooms"
            element={
              user ? (
                <Rooms 
                  rooms={rooms} 
                  setRooms={setRooms} 
                  user={user} 
                  assignments={assignments} 
                />
              ) : (
                <Navigate to="/login" replace />
              )
            }
          />

          <Route
            path="/supplies"
            element={
              user ? (
                <Supplies 
                  supplies={supplies} 
                  setSupplies={setSupplies} 
                  user={user} 
                />
              ) : (
                <Navigate to="/login" replace />
              )
            }
          />

          <Route
            path="/admin"
            element={
              user?.role === 'admin' ? (
                <Admin
                  rooms={rooms}
                  setRooms={setRooms}
                  supplies={supplies}
                  setSupplies={setSupplies}
                  assignments={assignments}
                  setAssignments={setAssignments}
                  broadcast={broadcast}
                  setBroadcast={setBroadcast}
                  setLogs={setLogs}
                  onlineUsers={onlineUsers}
                />
              ) : (
                <Navigate to="/dashboard" replace />
              )
            }
          />

          <Route path="*" element={<Navigate to={user ? "/dashboard" : "/login"} replace />} />
        </Routes>
      </main>

      {user && <Navbar user={user} />}
    </div>
  );
}