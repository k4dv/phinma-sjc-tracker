import React, { useState, useRef } from 'react';
import { useLocation } from 'react-router-dom';
import sjcLogo from '../assets/Logo.jpg';
import { 
  User, 
  LogOut, 
  Shield, 
  X, 
  Building2, 
  BadgeCheck, 
  AlertTriangle 
} from 'lucide-react';

export default function Header({ title, user, onLogout }) {
  const location = useLocation();
  const isAdmin = user?.role === 'admin';

  const [showProfileModal, setShowProfileModal] = useState(false);
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);
  
  // Real-time touch drag states
  const [dragY, setDragY] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const [isClosing, setIsClosing] = useState(false);
  const touchStartY = useRef(0);
  const currentDragY = useRef(0);

  // Dynamically resolve section label & title without jumping
  const getHeaderContext = () => {
    if (location.pathname.startsWith('/rooms')) {
      return {
        label: 'Room Inspection',
        fallbackTitle: 'Classroom Sanitation'
      };
    }
    if (location.pathname.startsWith('/supplies')) {
      return {
        label: 'Custodial Inventory',
        fallbackTitle: 'Supply Stockroom'
      };
    }
    if (location.pathname.startsWith('/admin')) {
      return {
        label: 'Supervisor Workspace',
        fallbackTitle: 'Admin Hub'
      };
    }
    return {
      label: 'Dashboard',
      fallbackTitle: `Hi, ${user?.name || 'Staff'}`
    };
  };

  const currentContext = getHeaderContext();

  // Smooth slide-down & fade-out closing animation
  const closeDrawer = () => {
    if (isClosing) return;
    setIsClosing(true);
    setTimeout(() => {
      setShowProfileModal(false);
      setIsClosing(false);
      setDragY(0);
      currentDragY.current = 0;
    }, 240);
  };

  const openDrawer = () => {
    setDragY(0);
    currentDragY.current = 0;
    setIsClosing(false);
    setShowProfileModal(true);
  };

  // Real-time touch drag handlers for the pull bar
  const onTouchStart = (e) => {
    touchStartY.current = e.touches[0].clientY;
    setIsDragging(true);
  };

  const onTouchMove = (e) => {
    const delta = e.touches[0].clientY - touchStartY.current;
    if (delta > 0) {
      currentDragY.current = delta;
      setDragY(delta);
    }
  };

  const onTouchEnd = () => {
    setIsDragging(false);
    if (currentDragY.current > 75) {
      closeDrawer();
    } else {
      setDragY(0);
      currentDragY.current = 0;
    }
  };

  const handleConfirmLogout = () => {
    setShowLogoutConfirm(false);
    setShowProfileModal(false);
    onLogout();
  };

  return (
    <>
      {/* Top Navbar with Saint Jude College Logo & Context */}
      <header className="bg-[#176e57] text-white px-4 pt-5 pb-4 shadow-sm sticky top-0 z-30">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            {/* Saint Jude College Logo */}
            <div className="w-9 h-9 rounded-xl bg-white p-0.5 shadow-sm flex items-center justify-center overflow-hidden flex-shrink-0">
              <img
                src={sjcLogo}
                alt="Saint Jude College"
                className="w-full h-full object-contain pointer-events-none rounded-lg"
              />
            </div>

            <div>
              {/* Opacity crossfade for category label */}
              <span 
                key={`${location.pathname}-label`}
                className="text-[11px] font-semibold uppercase tracking-wider text-emerald-200 block animate-fade leading-none"
              >
                {currentContext.label}
              </span>

              {/* Opacity crossfade for page title */}
              <h1 
                key={`${location.pathname}-title`}
                className="text-base font-semibold text-white tracking-tight mt-1 animate-fade leading-tight"
              >
                {location.pathname === '/dashboard' 
                  ? (title || `Hi, ${user?.name || 'Staff'}`) 
                  : currentContext.fallbackTitle}
              </h1>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Clickable Profile Avatar Button */}
            <button
              type="button"
              onClick={openDrawer}
              title="View Staff Profile"
              className="w-9 h-9 rounded-full bg-white/15 border border-white/20 flex items-center justify-center text-white hover:bg-white/25 active:scale-95 transition-transform duration-150"
            >
              {isAdmin ? (
                <Shield className="w-4 h-4 text-amber-300" />
              ) : (
                <User className="w-4 h-4" />
              )}
            </button>

            {/* Logout Trigger */}
            <button
              type="button"
              onClick={() => setShowLogoutConfirm(true)}
              title="Log Out"
              className="p-1.5 text-emerald-100 hover:text-white hover:bg-white/10 rounded-full active:scale-95 transition-all duration-150"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* PROFILE DETAILS: INTERACTIVE BOTTOM SHEET DRAWER */}
      {showProfileModal && (
        <div 
          className={`fixed inset-0 z-50 bg-black/45 backdrop-blur-[2px] flex items-end justify-center transition-opacity duration-240 ease-out ${
            isClosing ? 'opacity-0 pointer-events-none' : 'opacity-100 animate-fade-backdrop'
          }`}
          onClick={closeDrawer}
        >
          <div 
            style={{
              transform: isClosing ? 'translateY(100%)' : `translateY(${dragY}px)`,
              transition: isDragging ? 'none' : 'transform 0.24s cubic-bezier(0.16, 1, 0.3, 1)'
            }}
            className={`bg-white w-full max-w-md rounded-t-[28px] px-5 pt-2 pb-6 shadow-[0_-8px_30px_rgba(0,0,0,0.15)] space-y-4 border-t border-slate-100 select-none touch-none ${
              !isClosing && dragY === 0 ? 'animate-sheet-up' : ''
            }`}
            onClick={(e) => e.stopPropagation()}
          >
            {/* Clean Native Mobile Pull Bar (Touch-Draggable, No Text) */}
            <div 
              onTouchStart={onTouchStart}
              onTouchMove={onTouchMove}
              onTouchEnd={onTouchEnd}
              className="w-full py-2.5 cursor-grab active:cursor-grabbing flex justify-center items-center"
            >
              <div className="w-12 h-1.5 bg-slate-300 rounded-full active:bg-slate-400 transition-colors" />
            </div>

            {/* Sheet Header with Close 'X' Button */}
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <BadgeCheck className="w-5 h-5 text-[#176e57]" />
                <h2 className="text-sm font-bold text-slate-800">Custodial Profile</h2>
              </div>
              <button
                type="button"
                onClick={closeDrawer}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-100 active:scale-90 transition"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* User Identity Card */}
            <div className="flex items-center gap-3.5 bg-slate-50 p-3.5 rounded-2xl border border-slate-100">
              <div className="w-12 h-12 rounded-full bg-[#176e57] text-white flex items-center justify-center flex-shrink-0 shadow-sm">
                {isAdmin ? <Shield className="w-6 h-6 text-amber-300" /> : <User className="w-6 h-6" />}
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-800 leading-tight">{user?.name}</h3>
                <span className="text-[11px] font-semibold text-[#176e57] block">
                  {isAdmin ? 'Facilities Supervisor' : 'Custodial Personnel'}
                </span>
                <span className="text-[10px] text-slate-400 font-mono">ID: {user?.id}</span>
              </div>
            </div>

            {/* Specs */}
            <div className="space-y-2 text-xs">
              <div className="flex justify-between py-1.5 border-b border-slate-100">
                <span className="text-slate-500">Assigned Building</span>
                <span className="font-semibold text-slate-800 flex items-center gap-1">
                  <Building2 className="w-3.5 h-3.5 text-slate-400" /> Dimasalang Hall
                </span>
              </div>

              <div className="flex justify-between py-1.5 border-b border-slate-100">
                <span className="text-slate-500">Shift Status</span>
                <span className="font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md">
                  Active On Duty
                </span>
              </div>

              <div className="flex justify-between py-1.5">
                <span className="text-slate-500">Access Tier</span>
                <span className="font-semibold text-slate-700">
                  {isAdmin ? 'Full Supervisor Audit' : 'Floors, Rooms & Supplies'}
                </span>
              </div>
            </div>

            {/* Logout Action */}
            <div className="pt-2">
              <button
                type="button"
                onClick={() => {
                  closeDrawer();
                  setTimeout(() => setShowLogoutConfirm(true), 240);
                }}
                className="w-full py-2.5 rounded-xl border border-rose-200 text-rose-700 hover:bg-rose-50 active:scale-[0.98] text-xs font-semibold flex items-center justify-center gap-2 transition-all duration-150"
              >
                <LogOut className="w-3.5 h-3.5" /> End Shift & Log Out
              </button>
            </div>
          </div>
        </div>
      )}

      {/* LOGOUT CONFIRMATION DIALOG */}
      {showLogoutConfirm && (
        <div 
          className="fixed inset-0 z-50 bg-black/45 backdrop-blur-[2px] flex items-center justify-center p-4 animate-fade-backdrop"
          onClick={() => setShowLogoutConfirm(false)}
        >
          <div 
            className="bg-white w-full max-w-xs rounded-2xl p-5 shadow-2xl text-center space-y-3 animate-pop"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-11 h-11 rounded-2xl bg-amber-50 text-amber-700 mx-auto flex items-center justify-center animate-pop">
              <AlertTriangle className="w-5 h-5" />
            </div>

            <div>
              <h3 className="text-sm font-bold text-slate-800">Log Out of Portal?</h3>
              <p className="text-xs text-slate-500 mt-1">
                Are you sure you want to exit? Any unverified safety checks will require re-inspection upon login.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowLogoutConfirm(false)}
                className="py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 active:scale-95 text-slate-700 text-xs font-semibold transition"
              >
                Cancel
              </button>

              <button
                type="button"
                onClick={handleConfirmLogout}
                className="py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 active:scale-95 text-white text-xs font-semibold shadow-sm transition"
              >
                Yes, Log Out
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}