import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { DEMO_STAFF } from '../data/mockData';
import { supabase } from '../data/supabaseClient';
import { 
  CheckCircle2, 
  Circle, 
  Wind, 
  Lightbulb, 
  Lock, 
  Unlock, 
  Check, 
  RotateCcw,
  ShieldCheck,
  AlertCircle
} from 'lucide-react';

export default function Rooms({ rooms, setRooms, user, assignments }) {
  const location = useLocation();
  const isAdmin = user?.role === 'admin';
  const [selectedFloor, setSelectedFloor] = useState(1);
  const [lastToggledId, setLastToggledId] = useState(null);

  useEffect(() => {
    if (location.state?.targetFloor) {
      setSelectedFloor(location.state.targetFloor);
    }
  }, [location.state]);

  // 1. Toggle Room Cleaned / Pending Status
  const toggleRoomStatus = async (roomId) => {
    setLastToggledId(roomId);
    const now = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const targetRoom = rooms.find(r => r.id === roomId);
    if (!targetRoom) return;

    const isCurrentlyClean = targetRoom.status === 'cleaned' || targetRoom.status === 'verified';
    const updatedStatus = isCurrentlyClean ? 'pending' : 'cleaned';
    const updatedStaff = isCurrentlyClean ? 'Unassigned' : (user?.name || 'Staff');
    const updatedLastCleaned = isCurrentlyClean ? 'Marked pending' : now;

    // Optimistic UI state update
    setRooms(prev => prev.map(r => r.id === roomId ? {
      ...r,
      status: updatedStatus,
      staff: updatedStaff,
      lastCleaned: updatedLastCleaned,
      recleanReason: '',
      acChecked: !isCurrentlyClean,
      lightsChecked: !isCurrentlyClean,
      doorChecked: !isCurrentlyClean
    } : r));

    // Save directly to Supabase
    await supabase.from('rooms').update({
      status: updatedStatus,
      staff: updatedStaff,
      last_cleaned: updatedLastCleaned,
      reclean_reason: '',
      ac_checked: !isCurrentlyClean,
      lights_checked: !isCurrentlyClean,
      door_checked: !isCurrentlyClean
    }).eq('id', roomId);
  };

  // 2. Supervisor Approve Clean
  const handleSupervisorApprove = async (roomId) => {
    setLastToggledId(roomId);
    setRooms(prev => prev.map(r => r.id === roomId ? { ...r, status: 'verified', recleanReason: '' } : r));

    await supabase.from('rooms').update({
      status: 'verified',
      reclean_reason: ''
    }).eq('id', roomId);
  };

  // 3. Supervisor Flag Re-clean
  const handleSupervisorFlagReclean = async (roomId) => {
    const reason = prompt('Specify issue for custodial re-clean:') || 'Needs re-sanitation';
    setLastToggledId(roomId);
    setRooms(prev => prev.map(r => r.id === roomId ? { ...r, status: 'pending', recleanReason: reason } : r));

    await supabase.from('rooms').update({
      status: 'pending',
      reclean_reason: reason
    }).eq('id', roomId);
  };

  // 4. Toggle Safety Checklist (AC, Lights, Door)
  const toggleChecklist = async (roomId, field) => {
    const targetRoom = rooms.find(r => r.id === roomId);
    if (!targetRoom) return;

    const nextVal = !targetRoom[field];
    setRooms(prev => prev.map(r => r.id === roomId ? { ...r, [field]: nextVal } : r));

    const dbField = field === 'acChecked' ? 'ac_checked' : field === 'lightsChecked' ? 'lights_checked' : 'door_checked';
    await supabase.from('rooms').update({ [dbField]: nextVal }).eq('id', roomId);
  };

  const floorRooms = rooms.filter((r) => r.floor === selectedFloor);
  const floorDone = floorRooms.filter((r) => r.status === 'verified' || r.status === 'cleaned').length;
  const assignedStaffId = assignments[selectedFloor];
  const assignedStaffObj = DEMO_STAFF.find((s) => s.id === assignedStaffId);

  return (
    <div className="p-4 space-y-4 pb-20">
      
      {/* Floor Selector Pills */}
      <div className="bg-white p-2.5 rounded-2xl shadow-[0_2px_8px_rgba(0,0,0,0.04)] border border-slate-100">
        <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-400 block px-1 mb-1.5">
          Select Floor
        </span>
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
          {[1, 2, 3, 4, 5, 6, 7].map((floorNum) => {
            const isSelected = selectedFloor === floorNum;
            const fDone = rooms.filter((r) => r.floor === floorNum && (r.status === 'verified' || r.status === 'cleaned')).length;

            return (
              <button
                key={floorNum}
                onClick={() => setSelectedFloor(floorNum)}
                className={`flex-shrink-0 px-3 py-1.5 rounded-xl text-xs font-semibold active:scale-95 transition-all duration-150 flex items-center gap-1.5 ${
                  isSelected
                    ? 'bg-[#176e57] text-white shadow-sm scale-[1.02]'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                <span>Floor {floorNum}</span>
                <span className={`text-[10px] px-1.5 rounded-full ${
                  isSelected ? 'bg-white/20 text-white' : 'bg-slate-200 text-slate-700'
                }`}>
                  {fDone}/5
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Floor Overview Header */}
      <div className="px-1 flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold text-slate-800">Floor {selectedFloor} Rooms</h2>
          <p className="text-xs text-slate-500">
            {floorDone} of 5 completed &bull; Assigned: <strong>{assignedStaffObj?.name || 'Unassigned'}</strong>
          </p>
        </div>
      </div>

      {/* Rooms List */}
      <div className="space-y-3">
        {floorRooms.map((room) => {
          const isPending = room.status === 'pending';
          const isCleaned = room.status === 'cleaned';
          const isVerified = room.status === 'verified';
          const justUpdated = lastToggledId === room.id;

          return (
            <div
              key={room.id}
              className={`bg-white rounded-2xl p-4 shadow-[0_2px_8px_rgba(0,0,0,0.04)] border border-slate-100 space-y-3 transition-all duration-200 ${
                justUpdated ? 'ring-2 ring-[#176e57]/30' : ''
              }`}
            >
              <div className="flex justify-between items-center border-b border-slate-100 pb-2">
                <div>
                  <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">
                    Dimasalang Hall
                  </span>
                  <h3 className="text-lg font-bold text-slate-800 leading-none">
                    Room {room.id}
                  </h3>
                </div>

                {isVerified && (
                  <span className="bg-emerald-100 text-[#176e57] text-[10px] font-bold uppercase px-2.5 py-1 rounded-full flex items-center gap-1 animate-pop">
                    <ShieldCheck className="w-3.5 h-3.5" /> Verified
                  </span>
                )}
                {isCleaned && (
                  <span className="bg-amber-100 text-amber-900 text-[10px] font-bold uppercase px-2.5 py-1 rounded-full flex items-center gap-1 animate-pop">
                    <CheckCircle2 className="w-3.5 h-3.5 text-amber-700" /> Awaiting Audit
                  </span>
                )}
                {isPending && (
                  <span className="bg-rose-100 text-rose-800 text-[10px] font-bold uppercase px-2.5 py-1 rounded-full flex items-center gap-1 animate-pop">
                    <Circle className="w-3 h-3" /> Pending
                  </span>
                )}
              </div>

              {room.recleanReason && (
                <div className="p-2 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700 flex items-center gap-1.5 animate-pop">
                  <AlertCircle className="w-3.5 h-3.5 flex-shrink-0" />
                  <span><strong>Supervisor Flag:</strong> {room.recleanReason}</span>
                </div>
              )}

              <div className="grid grid-cols-2 gap-2 text-xs text-slate-600">
                <div>
                  <span className="text-[10px] text-slate-400 block">Inspected By</span>
                  <strong className="text-slate-700 font-medium">{room.staff}</strong>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block">Inspection Log</span>
                  <strong className="text-slate-700 font-medium">{room.lastCleaned}</strong>
                </div>
              </div>

              {/* Checklist */}
              <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100 space-y-1.5">
                <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-400 block">
                  Safety Checklist (Tap to toggle)
                </span>

                <div className="grid grid-cols-3 gap-1.5">
                  <button
                    type="button"
                    onClick={() => toggleChecklist(room.id, 'acChecked')}
                    className={`p-2 rounded-lg text-[10px] font-semibold flex flex-col items-center justify-center border active:scale-90 transition-all duration-150 ${
                      room.acChecked
                        ? 'bg-emerald-50 text-[#176e57] border-emerald-300 shadow-sm'
                        : 'bg-amber-50 text-amber-900 border-amber-300'
                    }`}
                  >
                    <Wind className={`w-3.5 h-3.5 mb-0.5 transition-transform duration-150 ${room.acChecked ? 'scale-110 text-[#176e57]' : ''}`} />
                    <span>{room.acChecked ? 'AC OFF' : 'AC ON'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => toggleChecklist(room.id, 'lightsChecked')}
                    className={`p-2 rounded-lg text-[10px] font-semibold flex flex-col items-center justify-center border active:scale-90 transition-all duration-150 ${
                      room.lightsChecked
                        ? 'bg-emerald-50 text-[#176e57] border-emerald-300 shadow-sm'
                        : 'bg-amber-50 text-amber-900 border-amber-300'
                    }`}
                  >
                    <Lightbulb className={`w-3.5 h-3.5 mb-0.5 transition-transform duration-150 ${room.lightsChecked ? 'scale-110 text-[#176e57]' : ''}`} />
                    <span>{room.lightsChecked ? 'Lights OFF' : 'Lights ON'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => toggleChecklist(room.id, 'doorChecked')}
                    className={`p-2 rounded-lg text-[10px] font-semibold flex flex-col items-center justify-center border active:scale-90 transition-all duration-150 ${
                      room.doorChecked
                        ? 'bg-emerald-50 text-[#176e57] border-emerald-300 shadow-sm'
                        : 'bg-rose-50 text-rose-800 border-rose-300'
                    }`}
                  >
                    {room.doorChecked ? (
                      <Lock className="w-3.5 h-3.5 mb-0.5 scale-110 text-[#176e57] transition-transform duration-150" />
                    ) : (
                      <Unlock className="w-3.5 h-3.5 mb-0.5 transition-transform duration-150" />
                    )}
                    <span>{room.doorChecked ? 'Locked' : 'Unlocked'}</span>
                  </button>
                </div>
              </div>

              {/* Supervisor Actions */}
              {isAdmin && isCleaned && (
                <div className="grid grid-cols-2 gap-2 pt-1">
                  <button
                    onClick={() => handleSupervisorApprove(room.id)}
                    className="py-2.5 bg-[#176e57] hover:bg-[#135c49] active:scale-95 text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all duration-150"
                  >
                    <ShieldCheck className="w-3.5 h-3.5" /> Approve Clean
                  </button>
                  <button
                    onClick={() => handleSupervisorFlagReclean(room.id)}
                    className="py-2.5 bg-rose-50 hover:bg-rose-100 active:scale-95 text-rose-800 border border-rose-200 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all duration-150"
                  >
                    <RotateCcw className="w-3.5 h-3.5" /> Flag Re-clean
                  </button>
                </div>
              )}

              {/* Mark Cleaned Trigger */}
              <button
                onClick={() => toggleRoomStatus(room.id)}
                className={`w-full py-2.5 rounded-xl font-semibold text-xs uppercase tracking-wide active:scale-[0.98] transition-all duration-150 flex items-center justify-center gap-1.5 ${
                  isPending
                    ? 'bg-[#176e57] hover:bg-[#135c49] text-white shadow-sm'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                }`}
              >
                {isPending ? (
                  <>
                    <Check className="w-3.5 h-3.5" /> Mark Cleaned (Request Audit)
                  </>
                ) : (
                  <>
                    <RotateCcw className="w-3.5 h-3.5" /> Mark as Pending
                  </>
                )}
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
}