import React, { useState } from 'react';
import { DEMO_STAFF } from '../data/mockData';
import { supabase } from '../data/supabaseClient';
import StaffPresenceModal from '../components/StaffPresenceModal';
import { 
  Shield, 
  Users, 
  Megaphone, 
  RotateCcw, 
  Plus,
  Send,
  Check,
  AlertTriangle,
  Trash2,
  Package,
  CheckCircle2,
  Loader2
} from 'lucide-react';

export default function Admin({
  rooms,
  setRooms,
  supplies,
  setSupplies,
  assignments,
  setAssignments,
  broadcast,
  setBroadcast,
  setLogs,
  onlineUsers = []
}) {
  const [activeTab, setActiveTab] = useState('broadcast');
  const [broadcastInput, setBroadcastInput] = useState(broadcast?.message || '');
  const [broadcastActive, setBroadcastActive] = useState(broadcast?.active ?? true);
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [noticeSaved, setNoticeSaved] = useState(false);
  const [deliveryReceived, setDeliveryReceived] = useState(false);
  const [showStaffModal, setShowStaffModal] = useState(false);
  
  // New supply item states
  const [newItemName, setNewItemName] = useState('');
  const [newItemCategory, setNewItemCategory] = useState('Chemicals');
  const [newItemQty, setNewItemQty] = useState('');
  const [newItemUnit, setNewItemUnit] = useState('pcs');
  const [newItemThreshold, setNewItemThreshold] = useState('');
  const [isAddingSupply, setIsAddingSupply] = useState(false);
  const [supplyAddedSuccess, setSupplyAddedSuccess] = useState('');

  const handleAssignChange = async (floorNum, staffId) => {
    setAssignments((prev) => ({
      ...prev,
      [floorNum]: staffId
    }));

    await supabase
      .from('assignments')
      .upsert({ floor: Number(floorNum), staff_id: staffId }, { onConflict: 'floor' });
  };

  const handleSaveBroadcast = async (e) => {
    e.preventDefault();
    const now = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    setBroadcast({
      active: broadcastActive,
      message: broadcastInput,
      postedBy: 'Supervisor',
      updatedAt: now
    });

    setNoticeSaved(true);
    setTimeout(() => setNoticeSaved(false), 2000);

    await supabase.from('broadcast').upsert({
      id: 1,
      message: broadcastInput,
      active: broadcastActive,
      posted_by: 'Supervisor',
      updated_at: now
    }, { onConflict: 'id' });

    const newLog = {
      id: `log-${Date.now()}`,
      time: now,
      author: 'Supervisor',
      text: `Announcement: "${broadcastInput}"`
    };
    await supabase.from('logs').insert([newLog]);
  };

  const handleClearBroadcast = async () => {
    setBroadcastInput('');
    setBroadcastActive(false);

    setBroadcast({
      active: false,
      message: '',
      postedBy: 'Supervisor',
      updatedAt: ''
    });

    await supabase.from('broadcast').upsert({
      id: 1,
      message: '',
      active: false,
      posted_by: 'Supervisor',
      updated_at: ''
    }, { onConflict: 'id' });
  };

  const executeShiftReset = async () => {
    const now = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    setRooms((prev) =>
      prev.map((room) => ({
        ...room,
        status: 'pending',
        lastCleaned: 'Shift Reset',
        recleanReason: '',
        acChecked: false,
        lightsChecked: false,
        doorChecked: false
      }))
    );

    setShowResetConfirm(false);

    await supabase
      .from('rooms')
      .update({
        status: 'pending',
        last_cleaned: 'Shift Reset',
        reclean_reason: '',
        ac_checked: false,
        lights_checked: false,
        door_checked: false
      })
      .gte('floor', 1);

    const logItem = {
      id: `log-${Date.now()}`,
      time: now,
      author: 'Supervisor',
      text: 'New shift initialized. All 35 rooms reset to Pending status.'
    };
    await supabase.from('logs').insert([logItem]);
  };

  const handleBatchDelivery = async () => {
    setDeliveryReceived(true);
    setTimeout(() => setDeliveryReceived(false), 1800);

    const lowItems = supplies.filter((s) => s.quantity <= s.threshold);

    setSupplies((prev) =>
      prev.map((item) =>
        item.quantity <= item.threshold ? { ...item, quantity: item.quantity + 10 } : item
      )
    );

    for (const item of lowItems) {
      await supabase
        .from('supplies')
        .update({ quantity: item.quantity + 10 })
        .eq('id', item.id);
    }
  };

  // ADD NEW ITEM WITH CONFIRMATION & NO DOUBLE-POST
  const handleAddSupply = async (e) => {
    e.preventDefault();
    if (!newItemName.trim() || !newItemQty || isAddingSupply) return;

    setIsAddingSupply(true);
    const itemName = newItemName.trim();
    const newItem = {
      id: `sup-${Date.now()}`,
      name: itemName,
      category: newItemCategory,
      quantity: Number(newItemQty),
      unit: newItemUnit.trim() || 'pcs',
      threshold: Number(newItemThreshold) || 3
    };

    try {
      // Single insert: Supabase Realtime in App.jsx will deliver it to all connected screens
      await supabase.from('supplies').insert([newItem]);

      // Show confirmation
      setSupplyAddedSuccess(`Added "${itemName}" (${newItem.quantity} ${newItem.unit}) to stock!`);
      setTimeout(() => setSupplyAddedSuccess(''), 3000);

      // Reset form
      setNewItemName('');
      setNewItemQty('');
      setNewItemThreshold('');
    } catch (err) {
      console.error('Failed to add supply:', err);
    } finally {
      setIsAddingSupply(false);
    }
  };

  // DELETE AN ITEM FROM DATABASE
  const handleDeleteSupply = async (supplyId, supplyName) => {
    if (!window.confirm(`Are you sure you want to delete "${supplyName}" from inventory?`)) return;

    // Optimistic removal
    setSupplies((prev) => prev.filter((s) => s.id !== supplyId));
    try {
      await supabase.from('supplies').delete().eq('id', supplyId);
    } catch (err) {
      console.error('Failed to delete supply item:', err);
    }
  };

  return (
    <div className="p-4 space-y-4 pb-24">
      <div className="bg-gradient-to-r from-amber-700 to-amber-900 text-white p-4 rounded-2xl shadow-sm flex items-center justify-between">
        <div>
          <span className="text-[10px] font-bold uppercase tracking-wider text-amber-200 block">
            Supervisor Workspace
          </span>
          <h2 className="text-base font-bold text-white">Dimasalang Admin Hub</h2>
          <p className="text-[11px] text-amber-100">Publish notices, manage staff & inventory.</p>
        </div>
        <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center animate-pop">
          <Shield className="w-6 h-6 text-amber-300" />
        </div>
      </div>

      <div className="grid grid-cols-4 gap-1 bg-white p-1 rounded-2xl border border-slate-200/80 text-[11px] font-semibold text-slate-500 shadow-sm">
        {['broadcast', 'assignments', 'supplies', 'rollover'].map((tabKey) => {
          const labels = {
            broadcast: 'Notice',
            assignments: 'Staff',
            supplies: 'Stock',
            rollover: 'Shift'
          };
          const isActive = activeTab === tabKey;

          return (
            <button
              key={tabKey}
              onClick={() => setActiveTab(tabKey)}
              className={`py-2 rounded-xl transition-all duration-150 active:scale-95 ${
                isActive ? 'bg-[#176e57] text-white shadow-sm font-bold scale-[1.02]' : 'hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              {labels[tabKey]}
            </button>
          );
        })}
      </div>

      <div key={activeTab} className="page-transition">
        {activeTab === 'broadcast' && (
          <div className="bg-white rounded-2xl p-4 shadow-[0_2px_8px_rgba(0,0,0,0.04)] border border-slate-100 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <div>
                <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wide">
                  Shift Broadcast Announcement
                </h3>
                <p className="text-[10px] text-slate-400">Pushes an urgent banner across custodial screens live.</p>
              </div>
              <Megaphone className="w-4 h-4 text-[#176e57]" />
            </div>

            <form onSubmit={handleSaveBroadcast} className="space-y-3">
              <div>
                <label className="text-[11px] font-semibold text-slate-600 block mb-1">
                  Announcement Text
                </label>
                <textarea
                  rows={3}
                  value={broadcastInput}
                  onChange={(e) => setBroadcastInput(e.target.value)}
                  placeholder="e.g. Sanitation inspection today at 4:00 PM. Please verify AC switches."
                  className="w-full p-2.5 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:border-[#176e57] focus:ring-1 focus:ring-[#176e57] transition"
                />
              </div>

              <div className="flex items-center justify-between">
                <label className="flex items-center gap-2 text-xs text-slate-700 font-medium cursor-pointer">
                  <input
                    type="checkbox"
                    checked={broadcastActive}
                    onChange={(e) => setBroadcastActive(e.target.checked)}
                    className="rounded text-[#176e57] focus:ring-[#176e57] transition"
                  />
                  <span>Display Banner Live</span>
                </label>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleClearBroadcast}
                    title="Delete announcement from all screens"
                    className="px-3 py-2 rounded-xl text-xs font-semibold flex items-center gap-1 text-rose-600 hover:bg-rose-50 border border-rose-200 active:scale-95 transition"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Clear</span>
                  </button>

                  <button
                    type="submit"
                    className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 active:scale-95 transition-all duration-150 ${
                      noticeSaved ? 'bg-emerald-600 text-white' : 'bg-[#176e57] hover:bg-[#135c49] text-white shadow-sm'
                    }`}
                  >
                    {noticeSaved ? (
                      <>
                        <Check className="w-3.5 h-3.5 animate-pop" /> Published!
                      </>
                    ) : (
                      <>
                        <Send className="w-3.5 h-3.5" /> Publish to All
                      </>
                    )}
                  </button>
                </div>
              </div>
            </form>
          </div>
        )}

        {activeTab === 'assignments' && (
          <div className="bg-white rounded-2xl p-4 shadow-[0_2px_8px_rgba(0,0,0,0.04)] border border-slate-100 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <div>
                <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wide">
                  Floor Assignment Matrix
                </h3>
                <p className="text-[10px] text-slate-400">Designate custodial personnel to each floor.</p>
              </div>

              <button
                type="button"
                onClick={() => setShowStaffModal(true)}
                title="View Online Staff"
                className="p-2 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-[#176e57] active:scale-95 transition flex items-center gap-1.5 border border-emerald-200/60 shadow-xs"
              >
                <Users className="w-4 h-4 text-[#176e57]" />
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              </button>
            </div>

            <div className="space-y-2">
              {[1, 2, 3, 4, 5, 6, 7].map((floorNum) => {
                const assignedStaffId = assignments[floorNum];

                return (
                  <div
                    key={floorNum}
                    className="flex items-center justify-between p-2.5 bg-slate-50 hover:bg-slate-100/70 rounded-xl border border-slate-100 text-xs transition"
                  >
                    <div className="flex items-center gap-2">
                      <span className="w-6 h-6 rounded-lg bg-[#176e57] text-white font-bold text-[10px] flex items-center justify-center shadow-xs">
                        F{floorNum}
                      </span>
                      <span className="font-semibold text-slate-800">Floor {floorNum}</span>
                    </div>

                    <select
                      value={assignedStaffId || '001'}
                      onChange={(e) => handleAssignChange(floorNum, e.target.value)}
                      className="bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs font-medium text-slate-700 focus:outline-none focus:border-[#176e57]"
                    >
                      {DEMO_STAFF.map((staff) => (
                        <option key={staff.id} value={staff.id}>
                          {staff.name} ({staff.id})
                        </option>
                      ))}
                    </select>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* STOCK / SUPPLIES TAB */}
        {activeTab === 'supplies' && (
          <div className="space-y-4">
            
            {/* Batch Restock Card */}
            <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-3.5 flex items-center justify-between shadow-xs">
              <div>
                <h4 className="text-xs font-bold text-emerald-900">Restock Low Items</h4>
                <p className="text-[10px] text-emerald-700">Add +10 units to all supplies at/below threshold in Supabase.</p>
              </div>
              <button
                onClick={handleBatchDelivery}
                className={`text-xs font-semibold px-3 py-1.5 rounded-xl active:scale-95 transition-all duration-150 flex-shrink-0 ${
                  deliveryReceived ? 'bg-emerald-700 text-white animate-pop' : 'bg-[#176e57] hover:bg-[#135c49] text-white shadow-sm'
                }`}
              >
                {deliveryReceived ? 'Shipment Received!' : 'Receive Delivery'}
              </button>
            </div>

            {/* Success Toast when Item is Added */}
            {supplyAddedSuccess && (
              <div className="p-3 bg-emerald-50 border border-emerald-300 text-emerald-800 text-xs font-semibold rounded-2xl flex items-center gap-2 animate-toast shadow-sm">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0 animate-pop" />
                <span>{supplyAddedSuccess}</span>
              </div>
            )}

            {/* Add New Inventory Item Form */}
            <div className="bg-white rounded-2xl p-4 shadow-[0_2px_8px_rgba(0,0,0,0.04)] border border-slate-100 space-y-3">
              <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wide border-b border-slate-100 pb-2 flex items-center justify-between">
                <span>Add New Inventory Item</span>
                <Package className="w-4 h-4 text-[#176e57]" />
              </h3>

              <form onSubmit={handleAddSupply} className="space-y-2.5 text-xs">
                <div>
                  <span className="text-[10px] font-semibold text-slate-500 block mb-1">Item Name</span>
                  <input
                    type="text"
                    required
                    value={newItemName}
                    onChange={(e) => setNewItemName(e.target.value)}
                    placeholder="e.g. Toilet Bowl Cleaner"
                    className="w-full p-2 border border-slate-200 rounded-lg text-xs text-slate-800 focus:outline-none focus:border-[#176e57]"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <span className="text-[10px] font-semibold text-slate-500 block mb-1">Category</span>
                    <select
                      value={newItemCategory}
                      onChange={(e) => setNewItemCategory(e.target.value)}
                      className="w-full p-2 border border-slate-200 rounded-lg text-xs text-slate-800 bg-white"
                    >
                      <option value="Chemicals">Chemicals</option>
                      <option value="Equipment">Equipment</option>
                      <option value="Disposables">Disposables</option>
                      <option value="Hygiene">Hygiene</option>
                      <option value="PPE">PPE</option>
                    </select>
                  </div>
                  <div>
                    <span className="text-[10px] font-semibold text-slate-500 block mb-1">Unit</span>
                    <input
                      type="text"
                      value={newItemUnit}
                      onChange={(e) => setNewItemUnit(e.target.value)}
                      placeholder="e.g. bottles, pcs, boxes"
                      className="w-full p-2 border border-slate-200 rounded-lg text-xs text-slate-800"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <span className="text-[10px] font-semibold text-slate-500 block mb-1">Initial Stock</span>
                    <input
                      type="number"
                      required
                      min="0"
                      value={newItemQty}
                      onChange={(e) => setNewItemQty(e.target.value)}
                      placeholder="e.g. 10"
                      className="w-full p-2 border border-slate-200 rounded-lg text-xs text-slate-800"
                    />
                  </div>
                  <div>
                    <span className="text-[10px] font-semibold text-slate-500 block mb-1">Low Alert Threshold</span>
                    <input
                      type="number"
                      min="1"
                      value={newItemThreshold}
                      onChange={(e) => setNewItemThreshold(e.target.value)}
                      placeholder="e.g. 3"
                      className="w-full p-2 border border-slate-200 rounded-lg text-xs text-slate-800"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isAddingSupply}
                  className="w-full bg-[#176e57] hover:bg-[#135c49] active:scale-[0.98] text-white py-2.5 rounded-xl font-semibold text-xs transition-all duration-150 flex items-center justify-center gap-1.5 shadow-sm disabled:opacity-75"
                >
                  {isAddingSupply ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Saving Item...</span>
                    </>
                  ) : (
                    <>
                      <Plus className="w-3.5 h-3.5" /> 
                      <span>Save New Item</span>
                    </>
                  )}
                </button>
              </form>
            </div>

            {/* Inventory Management List with Delete Buttons */}
            <div className="bg-white rounded-2xl p-4 shadow-[0_2px_8px_rgba(0,0,0,0.04)] border border-slate-100 space-y-3">
              <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                <div>
                  <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wide">
                    Manage Central Stockroom
                  </h3>
                  <p className="text-[10px] text-slate-400">Total: {supplies.length} tracked supplies</p>
                </div>
              </div>

              <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
                {supplies.map((item) => (
                  <div
                    key={item.id}
                    className="p-2.5 bg-slate-50 hover:bg-slate-100/70 rounded-xl border border-slate-100 text-xs flex items-center justify-between transition"
                  >
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-slate-800">{item.name}</span>
                        <span className="text-[9px] font-semibold text-slate-500 bg-white px-1.5 py-0.5 rounded border border-slate-200">
                          {item.category}
                        </span>
                      </div>
                      <p className="text-[10px] text-slate-500 mt-0.5">
                        Stock: <strong>{item.quantity}</strong> {item.unit} (Alert at &le; {item.threshold})
                      </p>
                    </div>

                    {/* Delete Item Button */}
                    <button
                      type="button"
                      onClick={() => handleDeleteSupply(item.id, item.name)}
                      title={`Delete ${item.name}`}
                      className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg active:scale-90 transition"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>

          </div>
        )}

        {activeTab === 'rollover' && (
          <div className="bg-white rounded-2xl p-4 shadow-[0_2px_8px_rgba(0,0,0,0.04)] border border-slate-100 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <div>
                <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wide">
                  Daily Shift Roll-Over
                </h3>
                <p className="text-[10px] text-slate-400">Initialize a new morning or afternoon inspection shift.</p>
              </div>
              <RotateCcw className="w-4 h-4 text-amber-700" />
            </div>

            <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-xs text-amber-900 space-y-1">
              <p className="font-bold flex items-center gap-1">
                <AlertTriangle className="w-3.5 h-3.5 text-amber-700" /> Database Reset Warning
              </p>
              <p className="text-[11px] leading-relaxed">
                Resetting will set all 35 rooms back to <strong>Pending</strong> in Supabase and uncheck AC, lighting, and door safety flags.
              </p>
            </div>

            {!showResetConfirm ? (
              <button
                onClick={() => setShowResetConfirm(true)}
                className="w-full py-3 bg-rose-600 hover:bg-rose-700 active:scale-[0.98] text-white rounded-xl text-xs font-semibold transition-all duration-150 shadow-sm"
              >
                Start New Shift (Reset 35 Rooms)
              </button>
            ) : (
              <div className="space-y-2 animate-pop">
                <p className="text-xs text-center font-bold text-slate-800">
                  Confirm reset of all 35 rooms across 7 floors?
                </p>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => setShowResetConfirm(false)}
                    className="py-2.5 bg-slate-100 hover:bg-slate-200 active:scale-95 text-slate-700 rounded-xl text-xs font-semibold transition"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={executeShiftReset}
                    className="py-2.5 bg-rose-600 hover:bg-rose-700 active:scale-95 text-white rounded-xl text-xs font-semibold transition shadow-sm"
                  >
                    Confirm Reset
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      <StaffPresenceModal
        isOpen={showStaffModal}
        onClose={() => setShowStaffModal(false)}
        onlineUsers={onlineUsers}
        assignments={assignments}
        currentUser={{ role: 'admin', id: 'admin', name: 'Facilities Supervisor' }}
      />
    </div>
  );
}